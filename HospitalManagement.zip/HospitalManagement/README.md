# 🏥 Hospital Management System (JDBC + MySQL)

A simple Java console project using JDBC to manage patients in a hospital database.

## 🚀 Features
- Add new patients
- View all patients
- Update patient disease
- Delete patient

## 🛠️ Tech Stack
- Java (17+)
- JDBC
- MySQL

## 🧩 Setup

1. Install MySQL and run this script to create database & table:

```sql
CREATE DATABASE hospitaldb;
USE hospitaldb;

CREATE TABLE patients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    age INT,
    disease VARCHAR(100)
);
```

2. Update DB credentials in `DBConnection.java` if needed:
   - Username: `HospitalAdmin`
   - Password: `Sayali123`

3. Add MySQL JDBC driver (`mysql-connector-j-x.x.x.jar`) to classpath.

4. Compile & run:

```bash
javac -d out src/com/hospital/*.java
java -cp "out;path/to/mysql-connector-java.jar" com.hospital.Main
```